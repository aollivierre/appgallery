#Unique Tracking ID: 1d7920d8-bc13-4a2c-be30-5a8e17755945, Timestamp: 2024-06-01 23:01:50
if (Test-Path "C:\Program Files\TeamViewer\TeamViewer.exe") { Write-Output "F"; exit 0 } else { exit 1 }
