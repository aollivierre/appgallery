# Unique Tracking ID: 0d27c873-f0eb-4691-b21f-9db3ca95c4c7, Timestamp: 2024-06-01 23:01:50
$msiPath = Join-Path -Path $PSScriptRoot -ChildPath "TV.msi"
$settingsFilePath = Join-Path -Path $PSScriptRoot -ChildPath "s.tvopt"
Start-Process -FilePath "MSIEXEC.EXE" -ArgumentList "/i", $msiPath, "/qn", "CUSTOMCONFIGID=he26pyq", "SETTINGSFILE=$settingsFilePath" -Wait
Start-Sleep -Seconds 30
Start-Process -FilePath "C:\Program Files\TeamViewer\TeamViewer.exe" -ArgumentList "assignment", "--id", "0001CoABChCA9yFwIIoR74tMZIyA33_LEigIACAAAgAJAFSqVMre4m7Q9RyL_9ZB4-yMHZK-UVSbZrqfcdrNwgGLGkB87dl_YlvrmSVBRLPlZHtgxOKBRCsH5wD51rSnBvur-t73_2BBrcvVkLgeG2xfQpR0kHYTCAflYNthXPh810lpIAEQuZvRqgY="