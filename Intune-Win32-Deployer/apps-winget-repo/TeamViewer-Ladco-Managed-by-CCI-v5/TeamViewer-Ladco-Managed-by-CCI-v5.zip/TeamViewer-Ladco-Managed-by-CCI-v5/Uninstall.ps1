#Unique Tracking ID: 53729fec-da72-47d7-844b-10bbda210cb2, Timestamp: 2024-06-01 23:01:50
msiexec /x "{9A9ED08E-912E-4749-B713-C3775EDFBA61}" /qn
